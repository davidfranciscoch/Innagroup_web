export interface IScrollspy {
	options?: {};
}
