export interface ITooltip {
	options?: {};
	
	show(): void;
	
	hide(): void;
}
