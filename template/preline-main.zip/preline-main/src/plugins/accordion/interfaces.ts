export interface IAccordion {
	options?: {};
	
	show(): void;
	
	hide(): void;
}
